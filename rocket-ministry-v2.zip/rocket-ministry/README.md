# Rocket Ministry Dashboard

## Deploy to Vercel (free, 5 minutes)

1. Go to https://vercel.com and create a free account
2. Click "Add New Project"
3. Upload this zip file or connect via GitHub
4. Click Deploy — done!

## Run locally
```
npm install
npm start
```
